Where are those Blender Addons?

Due to the fact that MathWorks.com supports only BSD license and those addons are distributed on GPL license, they could not be included in the MathWorks submission.

Addons are available at:
https://googledrive.com/host/0BybuboAGRbuvZEpab0hqOTlfZnc/Blender Addons.zip

I apologise for this additional difficulty.